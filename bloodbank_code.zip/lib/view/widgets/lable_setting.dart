import 'package:flutter/material.dart';

Widget lableSetting(
    {required String lable,
    required String initText,
    required String? Function(String?)? validator,
    bool readOnly = false,
    bool obsecure = false}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.end,
    children: [
      Directionality(
        textDirection: TextDirection.rtl,
        child: TextFormField(
          initialValue: initText,
          textAlign: TextAlign.right,
          readOnly: readOnly,
          validator: validator,
          obscureText: obsecure,
          decoration: InputDecoration(
              label: Text(
            lable,
            style: const TextStyle(color: Colors.grey, fontSize: 15),
          )),
        ),
      ),
      SizedBox(
        height: 15,
      )
    ],
  );
}
