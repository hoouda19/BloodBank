class InstructionModel {
  final String text;
  final String subtext;

  InstructionModel({required this.text, required this.subtext});
}
