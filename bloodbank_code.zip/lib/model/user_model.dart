class User {
  final String name;
  final String email;
  final String bloodType;
  final String country;
  final String number;
  User({
    required this.name,
    required this.email,
    required this.bloodType,
    required this.country,
    required this.number,
  });
}
