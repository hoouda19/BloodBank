class Onboardmodel {
  final String subtitle;
  final String image;

  final bool sec;

  Onboardmodel(this.subtitle, this.image, this.sec);
}
